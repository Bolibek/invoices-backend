// if (process.env.NODE_ENV === "production") {
//   module.exports = require("./production");
// } else {
//   module.exports = require("./dev");
// }

module.exports = {
  MONGO_URI:
    "mongodb+srv://bekkidev:Hf0PJJzjioBXFbLO@cluster0.ggwi7yj.mongodb.net/?retryWrites=true&w=majority",
  JWT_SECRET: "bolibekfayzullayev"
};
// 