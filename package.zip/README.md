# Backend part of Invoices Project

# Tools: Node.js, Express.js, MongoDB
